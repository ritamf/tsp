//
// Rita Ferrolho - 88822
// ...
//
// AED, 2018/2019
//
// solution of the traveling salesman problem
//

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "../cities.h"
#include "../elapsed_time.h"


//
// record best solutions
//

static int min_length, max_length, length; 
static int min_tour[max_n_cities + 1], max_tour[max_n_cities + 1];
static long n_tours;

//
// first solution (brute force, distance computed at the end, compute best and worst tours)
//

void tsp_v1(int n, int m, int * a) {
  int i, t;
  int j;
  if (m < n - 1)
    for (i = m; i < n; i++) {

      printf("1)");
      for (j = 0; j < n; j++)
        printf("%d%s", a[j], (j != n - 1) ? "-" : "\n");  
      t = a[m];
      a[m] = a[i];
      a[i] = t;

      printf("2)");
      for (j = 0; j < n; j++)
        printf("%d%s", a[j], (j != n - 1) ? "-" : "\n");
      
      //e por causa da linha abaixo q o else se repete mais q uma vez
      tsp_v1(n, m + 1, a);

      printf("4)");
      for (j = 0; j < n; j++)
        printf("%d%s", a[j], (j != n - 1) ? "-" : "\n");
      t = a[m];
      a[m] = a[i];
      a[i] = t;

      printf("5)");
      for (j = 0; j < n; j++)
        printf("%d%s", a[j], (j != n - 1) ? "-" : "\n");
      puts("-----------------");  
    }
  else { // visit permutation
    n_tours++;
    // este ciclo imprime todas as permutacoes

    printf("3) percurso: ");
    for (i = 0; i < n; i++) 
      printf("%d%s", a[i], (i != n - 1) ? "-" : "\n");//3 8
    // codigo acrescentado
    //minTour

    //maxTour

    #if !0
    printf("%d%s", a[i], (i == n - 1) ? "\n" : " ");

    //pretende se o output do min e max e imprimir as distancias
    if (i != n - 1) {
      length += cities[a[i]].distance[a[i + 1]];
      printf("ABCDEFGHIJKLMNOPQ");
    }
    else {
      puts("A TUA MAE EHHHHHHHHHHHH");
      length+=cities[a[i]].distance[a[0]];  
      printf("\nDistância do percurso: %d km\n\n",length);
      if(length < min_length) {
        min_length = length;
        printf("min length(para ja): %d", min_length);
        printf("min tour(para ja): ");
        for(i = 0; i<=n; i++) {
          min_tour[i] = a[i];
          printf("%d, ", min_tour[i]);
        }  
      }  
      else if(length > max_length) {
        max_length = length;
        printf("max length(para ja): %d", max_length);
        printf("min tour(para ja): ");
        for(i = 0; i<=n; i++) {
          max_tour[i] = a[i];
          printf("%d, ", min_tour[i]);
        }  
      }
    }
  #endif
  }
}

//
// second solution (dynamic programming)
//

void tsp_v2() {
  
} 

//
// main program
//

int main(int argc, char ** argv) {
  //int nMecanografico, especial, n, i, array[18]
  int n_mec, special, n, i, a[max_n_cities];
  char file_name[32];
  double dt1;

  n_mec = 88822; // já foi mudado
  special = 0; // igualar a um na parte final do projeto

  init_cities_data(n_mec, special); //os dados acerca de portugal sao introdizidos aqui

  printf("data for init_cities_data(%d,%d)\n", n_mec, special);
  fflush(stdout);
  #if 0
  print_distances();
  #endif

  for (n = 3; n <= 4; n++) { //em vez de n_cities
    //
    // try tsp_v1
    //
    dt1 = -1.0;
    if (n <= 16) { //em vez de 18
      (void) elapsed_time(); //contagem tempo comeca aqui
      for (i = 0; i < n; i++) 
        a[i] = i;
      min_length = 1000000000;
      max_length = 0;
      n_tours = 0l;

      tsp_v1(n, 1, a); // ultima cidade, cidade inicial, percurso
      dt1 = elapsed_time(); //contagem tempo termina aqui
      printf("tsp_v1() finished in %8.3fs (%ld tours generated)\n", dt1, n_tours);

      //distancia minima
      printf("Min tour: %5d [", min_length);
      for (i = 0; i < n; i++)
        printf("%2d%s", min_tour[i], (i == n - 1) ? "]\n" : ",");

      //distancia maxima
      printf("Max tour: %5d [", max_length);
      for (i = 0; i < n; i++)
        printf("%2d%s", max_tour[i], (i == n - 1) ? "]\n" : ",");

      fflush(stdout);
      if (argc == 2 && strcmp(argv[1], "-f") == 0) {
        min_tour[n] = -1;
        sprintf(file_name, "min_%02d.svg", n);
        make_map(file_name, min_tour);
        max_tour[n] = -1;
        sprintf(file_name, "max_%02d.svg", n);
        make_map(file_name, max_tour);
      }
    }
  }
  return 0;
}