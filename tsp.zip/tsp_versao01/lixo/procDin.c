#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "cities.h"
#include "elapsed_time.h"

static int min_length, max_length, length; 
static int min_tour[max_n_cities + 1], max_tour[max_n_cities + 1];
static long n_tours;


static int best_dist[18][1<<18];
int tsp_v2(int dest, int mask){
	int i, d, m = 1000000;
	if(best_dist[dest][mask] == 0){
		for(i = 0; i < 15; i++){ 
			if((mask&(1<<i))){
				d = tsp_v2(i, mask^(1<<i)) + cities[i].distance[dest];
				if(d < m){
					m = d;
					best_dist[dest][mask] = d;
				}
			}
		}
	}
	return m;
}

int main(int argc, char ** argv) {
  //PROGRAMACAO DINAMICA
  int n_mec, special, n, i, a[max_n_cities];
  char file_name[32];
  double dt1;

  for(n = 3;n <= n_cities;n++)
  {
    dt1 = -1.0;
    if(n <= 16)
    {
      (void)elapsed_time();
      for(i = 0;i < n;i++)
        a[i] = i;
      min_length = 1000000000;
      max_length = 0;
      n_tours = 0l;
      tsp_v1(n,1,a); // no need to change the starting city, as we are making a tour
      dt1 = elapsed_time();
      printf("tsp_v1() finished in %8.3fs (%ld tours generated)\n",dt1,n_tours);
      printf("  min %5d [",min_length);
      for(i = 0;i < n;i++)
        printf("%2d%s",min_tour[i],(i == n - 1) ? "]\n" : ",");
      printf("  max %5d [",max_length);
      for(i = 0;i < n;i++)
        printf("%2d%s",max_tour[i],(i == n - 1) ? "]\n" : ",");
      fflush(stdout);
      if(argc == 2 && strcmp(argv[1],"-f") == 0)
      {
        min_tour[n] = -1;
        sprintf(file_name,"min_%02d.svg",n);
        make_map(file_name,min_tour);
        max_tour[n] = -1;
        sprintf(file_name,"max_%02d.svg",n);
        make_map(file_name,max_tour);
      }
    }
  }
}