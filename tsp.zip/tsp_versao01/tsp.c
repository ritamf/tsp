// Nuno Monteiro - 79907
// Rita Ferrolho - 88822
// João Alcatrão - 76763
//
// AED, 2018/2019
//
// solution of the traveling salesman problem
//

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "cities.h"
#include "elapsed_time.h"


//
// record best solutions
//

static int min_length, max_length, length;
static int min_tour[max_n_cities + 1], max_tour[max_n_cities + 1];
static long n_tours;

//
// first solution (brute force, distance computed at the end, compute best and worst tours)
//

void tsp_v1(int n, int m, int * a) {
  int i, t;
  if (m < n - 1)
    for (i = m; i < n; i++) {
      t = a[m];
      a[m] = a[i];
      a[i] = t;
      tsp_v1(n, m + 1, a); 
      t = a[m];
      a[m] = a[i];
      a[i] = t;
    }
  else { // visit each permutation
    n_tours++;
    length = 0;
    for (i = 0; i < n; i++) {
      if (i < n)
        if (i != n - 1)
          length += cities[a[i]].distance[a[i + 1]];
        else {
          length += cities[a[i]].distance[a[0]];
          //printf("\nDistância do percurso: %d km\n\n",length);
          if (length < min_length) {
            min_length = length;
            for (i = 0; i <= n; i++)
              min_tour[i] = a[i];
          }
          if (length > max_length) {
            max_length = length;
            for (i = 0; i <= n; i++)
              max_tour[i] = a[i];
          }
        }
    }
  }
}

//
// second solution (dynamic programming, never computes the same route more than once)
//

static int best_dist[18][1 << 18];
int tsp_v2(int dest, int mask) {
  int i, d, m = 1000000;
  if (best_dist[dest][mask] == 0) {
    for (i = 0; i < 15; i++) {
      if ((mask & (1 << i))) {
        d = tsp_v2(i, mask ^ (1 << i)) + cities[i].distance[dest];
        if (d < m) {
          m = d;
          best_dist[dest][mask] = d;
        }
      }
    }
  }
  return m;
}


//
// main program
//

int main(int argc, char ** argv) {
  //int nMecanografico, especial, n, i, array[18]
  int n_mec, special, n, i, a[max_n_cities];
  char file_name[32];
  double dt1;

  n_mec = 0; // número mecanográfico
  special = 0; // matriz simétrica/assimétrica

  init_cities_data(n_mec, special); //os dados acerca de portugal sao introdizidos aqui

  printf("data for init_cities_data(%d,%d)\n", n_mec, special);
  fflush(stdout);

  # if !0 //  tabela de Distâncias 
  print_distances();
  #endif

  #if !0 // tabela Resultados
  printf("\n n|%13s|%12s|%5s|%5s|%-33s|%s \n", "n_tours", "dt1", "min_length", "max_length", "min_tour", "max_tour");
  for (n = 3; n <= 16; n++) { //em vez de n_cities
    //
    // try tsp_v1
    //
    dt1 = -1.0;

    if (n <= 16) { //em vez de 18
      (void) elapsed_time(); //contagem tempo comeca aqui
      // construcao do problema tsp
      for (i = 0; i < n; i++)
        a[i] = i;
      min_length = 1000000000;
      max_length = 0;
      n_tours = 0l;
      tsp_v1(n, 1, a); // no need to change the starting city, as we are making a tour
      dt1 = elapsed_time(); //contagem tempo termina aqui
      printf("%2d|%13ld|%11.6fs|", n, n_tours, dt1);

      //distancias
      printf("%8dkm|", min_length);
      printf("%8dkm|", max_length);

      //percursos
      char str_min_tour[80];
      int str_min_tour_pos = 0;

      for (i = 0; i < n; i++) //alterou-se neste ciclo o tipo de variável para String
        str_min_tour_pos += sprintf( & str_min_tour[str_min_tour_pos], "%d ", min_tour[i]);

      printf("%-33s|", str_min_tour);

      for (i = 0; i < n; i++)
        printf("%d%s", max_tour[i], (i == n - 1) ? "\n" : " "); // preservou-se o tipo da variável
      fflush(stdout);

      // mapas(já não faz parte da tabela de resultados)
      if (argc == 2 && strcmp(argv[1], "-f") == 0) {
        min_tour[n] = -1;
        sprintf(file_name, "min_%02d.svg", n);
        make_map(file_name, min_tour);

        max_tour[n] = -1;
        sprintf(file_name, "max_%02d.svg", n);
        make_map(file_name, max_tour);
      }
    }
  }
  #endif
  return 0;
}