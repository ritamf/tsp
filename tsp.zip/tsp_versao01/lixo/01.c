# include <stdio.h>
#include <string.h>

main() {

    	if(strcmp("A","B") != 0) 
      		printf("A cidade foi descoberta!\n");
}