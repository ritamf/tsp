#include <stdio.h>
#include <stdlib.h>

int main () {
   int numeroQualquer=1;
   printf("Start of the program....\n");
   
   printf("Exiting the program....\n");
   exit(numeroQualquer);

   printf("End of the program....\n");

   return(0);
}